python --version
